# Testar o Meu Ubuntu 0.6.0-beta.3

## Ambiente suportado

Ubuntu **26.04 LTS**, GNOME, computador **amd64/x86_64**. Não há suporte nesta beta para versões anteriores, outras distribuições ou ARM. Comece pelo modo de simulação; a instalação real precisa de ligação à Internet e autorização administrativa para operações de sistema.

## Instalar e abrir

Envie estes três ficheiros de `dist/`: `meu-ubuntu_0.6.0-beta.3_amd64.deb`, `meu-ubuntu-0.6.0-beta.3-linux-amd64` e `SHA256SUMS`. Na pasta recebida:

```bash
sha256sum -c SHA256SUMS
sudo apt install ./meu-ubuntu_0.6.0-beta.3_amd64.deb
meu-ubuntu --simular
```

Abra a aplicação como utilizador normal. Para experimentar operações reais depois da simulação, encerre-a e execute `meu-ubuntu`, ou use o atalho do menu. O manual acompanha o pacote em `/usr/share/doc/meu-ubuntu/manual.md`; também está disponível em **Ajuda e manual**.

## Roteiro de 15–20 minutos

Faça as tarefas sem consultar o manual inicialmente. Registe onde hesitou, o que esperava e o resultado. Não há respostas certas a decorar.

1. Comece com **Escolher do zero**. Encontre o Visual Studio Code pesquisando `VSCode`; escolha-o e também `htop`.
2. Descubra onde ver tudo o que escolheu. Antes de abrir o plano, explique com as suas palavras o que será instalado.
3. No catálogo, use **Mostrar catálogo de** para ver outro perfil. Confira se isso mudou as suas escolhas ou apenas os itens apresentados.
4. Em **Minhas escolhas**, tente limpar e cancele. Depois confirme a limpeza e use **Desfazer limpeza**. Confira se recuperou tudo.
5. Guarde as escolhas como um perfil chamado `Meu teste`. Encontre-o novamente em **Perfis prontos → Os meus**.
6. Abra um perfil incluído e examine as escolhas antes de o adicionar. Veja se distingue adicionar de substituir.
7. Abra **Agentes de IA**, escolha um agente e consulte as instruções de arranque. Reveja o plano: a dependência Node.js deve aparecer se necessária, e a instalação do agente deve ser por utilizador.
8. Feche a simulação e abra `meu-ubuntu` sem aplicar um plano. Em **Diagnóstico → Entradas de arranque**, confira se distingue comandos disponíveis, entradas desativadas e executáveis não encontrados; consulte a origem de uma entrada que não reconhece. Feche e volte a abrir com `--simular`.
9. Ainda em simulação, reveja e aplique um plano pequeno. Observe progresso, resultado e histórico. Retire uma aplicação instalada das escolhas: deve continuar como Já instalado e indicar que será mantida. Reveja as escolhas já aplicadas: o plano deve mostrar zero alterações, sem reinstalações ou reversões. Feche e reabra para verificar que o perfil guardado permanece.

Opcionalmente, num Ubuntu 26.04 de teste, repita uma instalação real pequena, como `htop`. Instale um agente apenas se quiser usá-lo; autenticação, subscrição e eventuais custos dependem do fornecedor. A aplicação não pede chaves nem inicia sessões por si.

## Enviar feedback

Para cada dificuldade, envie: versão do Meu Ubuntu; versão do Ubuntu e sessão Wayland/X11; resolução; tarefa; passos; resultado esperado; resultado observado; captura ou gravação, se possível. Remova credenciais e dados pessoais. Diga também se concluiu sem ajuda e avalie a facilidade da tarefa de 1 (muito difícil) a 5 (muito fácil).

## Limites da beta

É uma beta para recolher feedback. A avaliação automatizada e especializada não substitui sessões com pessoas: instalações administrativas, GNOME/Wayland, polkit e autenticação dos agentes precisam de confirmação em computadores reais. Os modos PDF/CSV/Excel, suporte a outras distribuições e novos perfis profissionais ficaram para uma fase posterior.
